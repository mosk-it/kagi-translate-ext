(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // src/popup.ts
  var require_popup = __commonJS({
    "src/popup.ts"(exports) {
      var TranslateApp = class {
        constructor() {
          __publicField(this, "translateText");
          __publicField(this, "fromLangEl");
          __publicField(this, "toLangEl");
          __publicField(this, "translateButton");
          __publicField(this, "reverseLangsButton");
          __publicField(this, "resultDiv");
          __publicField(this, "settings");
          __publicField(this, "browser");
          this.translateText = document.getElementById("translateText");
          this.fromLangEl = document.getElementById("fromLang");
          this.toLangEl = document.getElementById("toLang");
          this.translateButton = document.getElementById("translateButton");
          this.reverseLangsButton = document.getElementById("reverseLangsButton");
          this.resultDiv = document.getElementById("result");
          this.settings = { token: "", fromLang: "", toLang: "", selectedLanguages: [] };
        }
        initialize() {
          return __async(this, null, function* () {
            this.loadText();
            yield this.loadStoredLanguages();
            this.attachEventListeners();
          });
        }
        storeSelectedText(msg) {
          return __async(this, null, function* () {
            yield browser.storage.local.set({
              translatedSelectedText2: msg
            });
            browser.storage.local.get("translatedSelectedText2").then((r) => {
              console.log(r);
            });
          });
        }
        /*
         * Loads either currently selected text or previously selected (if no selection)
         */
        loadText() {
          return __async(this, null, function* () {
            const [tab] = yield browser.tabs.query({ active: true, currentWindow: true });
            let selText = yield browser.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                return window.getSelection().toString();
              }
            }).then((results) => {
              if (results && results[0]) {
                let selText2 = results[0].result;
                return selText2;
              }
            });
            if (selText) {
              this.storeSelectedText(selText);
              this.translateText.value = selText;
              this.translateText.focus();
            } else {
              const storedData = yield browser.storage.local.get("translatedSelectedText2");
              if (storedData.translatedSelectedText2) {
                this.translateText.value = storedData.translatedSelectedText2;
                this.translateText.focus();
              }
            }
          });
        }
        loadStoredLanguages() {
          return __async(this, null, function* () {
            const result = yield browser.storage.sync.get(["selectedLanguages", "fromLang", "toLang"]);
            const selectedLanguages = result.selectedLanguages || [];
            this.settings.selectedLanguages = selectedLanguages;
            this.populateLanguageDropdown(this.fromLangEl, selectedLanguages);
            this.populateLanguageDropdown(this.toLangEl, selectedLanguages);
            if (result.fromLang) this.fromLangEl.value = result.fromLang;
            if (result.toLang) this.toLangEl.value = result.toLang;
          });
        }
        populateLanguageDropdown(selectElement, languages) {
          selectElement.innerHTML = "";
          languages.forEach((lang) => {
            const option = document.createElement("option");
            option.setAttribute("value", lang);
            option.textContent = lang;
            selectElement.appendChild(option);
          });
        }
        attachEventListeners() {
          this.fromLangEl.addEventListener("change", () => {
            browser.storage.sync.set({ fromLang: this.fromLangEl.value });
          });
          this.toLangEl.addEventListener("change", () => {
            browser.storage.sync.set({ toLang: this.toLangEl.value });
          });
          this.reverseLangsButton.addEventListener("click", () => {
            this.reverseLanguages();
          });
          this.translateButton.addEventListener("click", () => __async(this, null, function* () {
            yield this.translateTextToOtherLanguage();
          }));
        }
        reverseLanguages() {
          const tmp = this.fromLangEl.value;
          this.fromLangEl.value = this.toLangEl.value;
          this.toLangEl.value = tmp;
        }
        translateTextToOtherLanguage() {
          return __async(this, null, function* () {
            const text = this.translateText.value.trim();
            if (!text) return;
            const settings = yield browser.storage.sync.get(["token"]);
            const token = settings.token || "";
            try {
              yield browser.cookies.set({
                url: "https://translate.kagi.com",
                name: "kagi_session",
                value: token,
                domain: ".kagi.com",
                secure: true
              });
              const response = yield fetch("https://translate.kagi.com/?/translate", {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded",
                  "Authorization": token,
                  "Accept": "application/json"
                },
                credentials: "include",
                body: new URLSearchParams({
                  from: this.fromLangEl.value,
                  to: this.toLangEl.value,
                  text
                })
              });
              if (!response.ok) {
                throw new Error("Translation request failed");
              }
              const data = yield response.json();
              this.resultDiv.textContent = JSON.parse(data.data)[2] || "Translation failed";
            } catch (error) {
              this.resultDiv.textContent = "Error translating text";
            }
          });
        }
      };
      document.addEventListener("DOMContentLoaded", () => __async(exports, null, function* () {
        const app = new TranslateApp();
        yield app.initialize();
      }));
    }
  });
  require_popup();
})();
