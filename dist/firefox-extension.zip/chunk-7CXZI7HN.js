import {
  __async,
  __asyncGenerator,
  __await,
  __esm,
  __forAwait,
  __publicField
} from "./chunk-VHMBIJIQ.js";

// src/shared/translateapi.ts
var TranslateAPI;
var init_translateapi = __esm({
  "src/shared/translateapi.ts"() {
    TranslateAPI = class {
      constructor() {
        __publicField(this, "model", "standard");
      }
      getAPIHeaders() {
        return {
          Accept: "*/*",
          "Accept-Language": "en-US,en;q=0.5",
          "Content-Type": "application/json",
          "X-Signal": "abortable",
          Pragma: "no-cache",
          "Cache-Control": "no-cache",
          Priority: "u=4"
        };
      }
      _makeRequest(endpoint, body) {
        return __async(this, null, function* () {
          const response = yield fetch(`https://translate.kagi.com/api${endpoint}`, {
            credentials: "include",
            headers: this.getAPIHeaders(),
            method: "POST",
            mode: "cors",
            body: JSON.stringify(body)
          });
          if (!response.ok) {
            throw new Error(`Request failed: ${response.status} ${response.statusText}`);
          }
          return response.json();
        });
      }
      detectLang(text) {
        return __async(this, null, function* () {
          const data = yield this._makeRequest("/detect", { text });
          return data.language;
        });
      }
      streamResponse(response) {
        return __asyncGenerator(this, null, function* () {
          const reader = response.body.getReader();
          const decoder = new TextDecoder();
          let buffer = "";
          while (true) {
            const { done, value } = yield new __await(reader.read());
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop();
            for (const line of lines) {
              if (line.startsWith("data: ")) {
                const data = line.slice(6);
                if (data === "[DONE]") return;
                try {
                  const parsed = JSON.parse(data);
                  yield parsed.delta || "";
                } catch (e) {
                }
              }
            }
          }
        });
      }
      translate(_0, _1, _2) {
        return __async(this, arguments, function* (text, fromLang, toLang, options = {}) {
          const { stream = false, onUpdate } = options;
          try {
            let body = {
              from: fromLang,
              to: toLang,
              text: text.trim(),
              stream,
              prediction: "",
              formality: "default",
              speaker_gender: "unknown",
              addressee_gender: "unknown",
              translation_style: "natural",
              context: "",
              model: this.model,
              dictionary_language: "en"
            };
            const response = this._makeRequest("/translate", body);
            if (stream && onUpdate) {
              let fullText = "";
              try {
                for (var iter = __forAwait(this.streamResponse(response)), more, temp, error; more = !(temp = yield iter.next()).done; more = false) {
                  const chunk = temp.value;
                  fullText += chunk;
                  onUpdate(chunk);
                }
              } catch (temp) {
                error = [temp];
              } finally {
                try {
                  more && (temp = iter.return) && (yield temp.call(iter));
                } finally {
                  if (error)
                    throw error[0];
                }
              }
              return fullText;
            } else {
              const data = yield response.json();
              return data.text || data.translation || "";
            }
          } catch (e) {
            console.log("Error translating: ", e.messages);
          }
        });
      }
    };
  }
});

export {
  TranslateAPI,
  init_translateapi
};
