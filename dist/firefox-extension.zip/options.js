var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { getBrowser } from './webext-polyfill.js';
class SettingsManager {
    constructor() {
        this.allLanguages = [
            'Automatic', 'English', 'Spanish', 'French', 'German', 'Italian',
            'Portuguese', 'Russian', 'Chinese', 'Japanese', 'Arabic', 'Korean',
            'Dutch', 'Swedish', 'Polish', 'Turkish', 'Hindi', 'Hebrew', 'Thai',
            'Vietnamese', 'Indonesian', 'Filipino', 'Malay'
        ];
        this.browser = getBrowser();
        this.kagiToken = document.getElementById('kagiToken');
        this.languageFilter = document.getElementById('languageFilter');
        this.languageGrid = document.getElementById('languageGrid');
        this.saveButton = document.getElementById('saveSettings');
        this.statusDiv = document.getElementById('status');
        this.initialize();
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            this.renderLanguagesCheckboxes(this.allLanguages);
            yield this.restoreSelectedLanguages();
            this.addEventListeners();
        });
    }
    renderLanguagesCheckboxes(languages) {
        this.languageGrid.innerHTML = '';
        languages.forEach(lang => {
            const languageDiv = this.createLanguageCheckbox(lang);
            this.languageGrid.appendChild(languageDiv);
        });
    }
    createLanguageCheckbox(lang) {
        const languageDiv = document.createElement('div');
        languageDiv.classList.add('language-checkbox');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `lang-${lang}`;
        checkbox.value = lang;
        const label = document.createElement('label');
        label.htmlFor = `lang-${lang}`;
        label.textContent = lang;
        languageDiv.appendChild(checkbox);
        languageDiv.appendChild(label);
        return languageDiv;
    }
    restoreSelectedLanguages() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield this.browser.storage.sync.get(['selectedLanguages', 'token']);
                this.kagiToken.value = result.token || '';
                const selectedLanguages = result.selectedLanguages || [];
                document.querySelectorAll('#languageGrid input[type="checkbox"]').forEach((checkbox) => {
                    checkbox.checked = selectedLanguages.includes(checkbox.value);
                });
            }
            catch (error) {
                console.error('Error restoring settings:', error);
            }
        });
    }
    addEventListeners() {
        this.saveButton.addEventListener('click', this.saveSettings.bind(this));
    }
    /*
     * extracts token from url like https://kagi.com/search?token=ZZZ.YYY
     */
    getTokenOutOfURLParams() {
        this.kagiToken.value = (new URLSearchParams((new URL(this.kagiToken.value)).search)).get('token');
    }
    saveSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            const selectedLanguages = this.getSelectedLanguages();
            try {
                let token = this.kagiToken.value;
                if (token.includes('kagi.com') && token.includes('token=')) {
                    this.getTokenOutOfURLParams();
                }
                yield this.browser.storage.sync.set({
                    token: this.kagiToken.value.trim(),
                    selectedLanguages
                });
                this.showStatusMessage('Settings saved successfully!', 'success');
            }
            catch (error) {
                this.showStatusMessage('Error saving settings', 'error');
                console.error('Error saving settings:', error);
            }
        });
    }
    getSelectedLanguages() {
        return Array.from(document.querySelectorAll('#languageGrid input[type="checkbox"]:checked'))
            .map((checkbox) => checkbox.value);
    }
    showStatusMessage(message, statusClass) {
        this.statusDiv.textContent = message;
        this.statusDiv.className = statusClass;
        setTimeout(() => {
            this.statusDiv.textContent = '';
            this.statusDiv.className = '';
        }, 3000);
    }
}
// Initialize the SettingsManager when the DOM content is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SettingsManager();
});
