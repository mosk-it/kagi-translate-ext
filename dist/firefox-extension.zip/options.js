(() => {
  var __defProp = Object.defineProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // src/languages.ts
  var ALL_LANGUAGES = [
    { lang: "Automatic", hide: false },
    { lang: "Abkhaz", hide: true },
    { lang: "Acehnese", hide: true },
    { lang: "Acholi", hide: true },
    { lang: "Afar", hide: true },
    { lang: "Afrikaans", hide: true },
    { lang: "Albanian", hide: true },
    { lang: "Alur", hide: true },
    { lang: "Amharic", hide: true },
    { lang: "Arabic", hide: false },
    { lang: "Armenian", hide: true },
    { lang: "Assamese", hide: true },
    { lang: "Avar", hide: true },
    { lang: "Awadhi", hide: true },
    { lang: "Aymara", hide: true },
    { lang: "Azerbaijani", hide: true },
    { lang: "Balinese", hide: true },
    { lang: "Baluchi", hide: true },
    { lang: "Bambara", hide: true },
    { lang: "Baoul\xE9", hide: true },
    { lang: "Bashkir", hide: true },
    { lang: "Basque", hide: true },
    { lang: "Batak Karo", hide: true },
    { lang: "Batak Simalungun", hide: true },
    { lang: "Batak Toba", hide: true },
    { lang: "Belarusian", hide: true },
    { lang: "Bemba", hide: true },
    { lang: "Bengali", hide: true },
    { lang: "Betawi", hide: true },
    { lang: "Bhojpuri", hide: true },
    { lang: "Bikol", hide: true },
    { lang: "Bosnian", hide: true },
    { lang: "Breton", hide: true },
    { lang: "Bulgarian", hide: true },
    { lang: "Buryat", hide: true },
    { lang: "Cantonese", hide: true },
    { lang: "Catalan", hide: true },
    { lang: "Cebuano", hide: true },
    { lang: "Chamorro", hide: true },
    { lang: "Chechen", hide: true },
    { lang: "Chichewa", hide: true },
    { lang: "Chinese (Simplified)", hide: false },
    { lang: "Chinese (Traditional)", hide: true },
    { lang: "Chuukese", hide: true },
    { lang: "Chuvash", hide: true },
    { lang: "Corsican", hide: true },
    { lang: "Crimean Tatar", hide: true },
    { lang: "Croatian", hide: true },
    { lang: "Czech", hide: true },
    { lang: "Danish", hide: true },
    { lang: "Dari", hide: true },
    { lang: "Dhivehi", hide: true },
    { lang: "Dinka", hide: true },
    { lang: "Dogri", hide: true },
    { lang: "Dombe", hide: true },
    { lang: "Dutch", hide: false },
    { lang: "Dyula", hide: true },
    { lang: "Dzongkha", hide: true },
    { lang: "Elvish", hide: true },
    { lang: "Emoji Speak", hide: true },
    { lang: "English", hide: false },
    { lang: "Esperanto", hide: true },
    { lang: "Estonian", hide: true },
    { lang: "Ewe", hide: true },
    { lang: "Faroese", hide: true },
    { lang: "Fijian", hide: true },
    { lang: "Filipino", hide: false },
    { lang: "Finnish", hide: true },
    { lang: "Fon", hide: true },
    { lang: "French", hide: false },
    { lang: "Frisian", hide: true },
    { lang: "Friulian", hide: true },
    { lang: "Fulani", hide: true },
    { lang: "Ga", hide: true },
    { lang: "Galician", hide: true },
    { lang: "Georgian", hide: true },
    { lang: "German", hide: false },
    { lang: "Greek", hide: true },
    { lang: "Guarani", hide: true },
    { lang: "Gujarati", hide: true },
    { lang: "Haitian Creole", hide: true },
    { lang: "Hakha Chin", hide: true },
    { lang: "Hausa", hide: true },
    { lang: "Hawaiian", hide: true },
    { lang: "Hebrew", hide: false },
    { lang: "Hiligaynon", hide: true },
    { lang: "Hindi", hide: false },
    { lang: "Hmong", hide: true },
    { lang: "Hungarian", hide: true },
    { lang: "Hunsrik", hide: true },
    { lang: "Iban", hide: true },
    { lang: "Icelandic", hide: true },
    { lang: "Igbo", hide: true },
    { lang: "Ilocano", hide: true },
    { lang: "Indonesian", hide: false },
    { lang: "Irish", hide: true },
    { lang: "Italian", hide: false },
    { lang: "Jamaican Patois", hide: true },
    { lang: "Japanese", hide: false },
    { lang: "Javanese", hide: true },
    { lang: "Jingpo", hide: true },
    { lang: "Kalaallisut", hide: true },
    { lang: "Kannada", hide: true },
    { lang: "Kanuri", hide: true },
    { lang: "Kapampangan", hide: true },
    { lang: "Kazakh", hide: true },
    { lang: "Khasi", hide: true },
    { lang: "Khmer", hide: true },
    { lang: "Kiga", hide: true },
    { lang: "Kikongo", hide: true },
    { lang: "Kinyarwanda", hide: true },
    { lang: "Kituba", hide: true },
    { lang: "Klingon", hide: true },
    { lang: "Kokborok", hide: true },
    { lang: "Komi", hide: true },
    { lang: "Konkani", hide: true },
    { lang: "Korean", hide: false },
    { lang: "Krio", hide: true },
    { lang: "Kurdish (Kurmanji)", hide: true },
    { lang: "Kurdish (Sorani)", hide: true },
    { lang: "Kyrgyz", hide: true },
    { lang: "Lao", hide: true },
    { lang: "Latgalian", hide: true },
    { lang: "Latin", hide: true },
    { lang: "Latvian", hide: true },
    { lang: "Ligurian", hide: true },
    { lang: "Limburgish", hide: true },
    { lang: "Lingala", hide: true },
    { lang: "Lithuanian", hide: true },
    { lang: "Lombard", hide: true },
    { lang: "Luganda", hide: true },
    { lang: "Luo", hide: true },
    { lang: "Luxembourgish", hide: true },
    { lang: "Macedonian", hide: true },
    { lang: "Madurese", hide: true },
    { lang: "Maithili", hide: true },
    { lang: "Makassar", hide: true },
    { lang: "Malagasy", hide: true },
    { lang: "Malay", hide: false },
    { lang: "Malay (Jawi)", hide: true },
    { lang: "Malayalam", hide: true },
    { lang: "Maltese", hide: true },
    { lang: "Mam", hide: true },
    { lang: "Manx", hide: true },
    { lang: "Maori", hide: true },
    { lang: "Marathi", hide: true },
    { lang: "Marshallese", hide: true },
    { lang: "Marwadi", hide: true },
    { lang: "Mauritian Creole", hide: true },
    { lang: "Meadow Mari", hide: true },
    { lang: "Meiteilon (Manipuri)", hide: true },
    { lang: "Middle English", hide: true },
    { lang: "Minang", hide: true },
    { lang: "Mizo", hide: true },
    { lang: "Mongolian", hide: true },
    { lang: "Myanmar (Burmese)", hide: true },
    { lang: "NKo", hide: true },
    { lang: "Nahuatl (Eastern Huasteca)", hide: true },
    { lang: "Ndau", hide: true },
    { lang: "Ndebele (South)", hide: true },
    { lang: "Nepalbhasa (Newari)", hide: true },
    { lang: "Nepali", hide: true },
    { lang: "Norwegian", hide: true },
    { lang: "Nuer", hide: true },
    { lang: "Occitan", hide: true },
    { lang: "Odia (Oriya)", hide: true },
    { lang: "Oromo", hide: true },
    { lang: "Ossetian", hide: true },
    { lang: "Pangasinan", hide: true },
    { lang: "Papiamento", hide: true },
    { lang: "Pashto", hide: true },
    { lang: "Persian", hide: true },
    { lang: "Pirate Speak", hide: true },
    { lang: "Polish", hide: false },
    { lang: "Portuguese (Brazil)", hide: false },
    { lang: "Portuguese (Portugal)", hide: true },
    { lang: "Punjabi (Gurmukhi)", hide: true },
    { lang: "Punjabi (Shahmukhi)", hide: true },
    { lang: "Quechua", hide: true },
    { lang: "Q\u02BCeqchi\u02BC", hide: true },
    { lang: "Romani", hide: true },
    { lang: "Romanian", hide: true },
    { lang: "Rundi", hide: true },
    { lang: "Russian", hide: true },
    { lang: "Sami (North)", hide: true },
    { lang: "Samoan", hide: true },
    { lang: "Sango", hide: true },
    { lang: "Sanskrit", hide: true },
    { lang: "Santali", hide: true },
    { lang: "Scots Gaelic", hide: true },
    { lang: "Sepedi", hide: true },
    { lang: "Serbian", hide: true },
    { lang: "Sesotho", hide: true },
    { lang: "Seychellois Creole", hide: true },
    { lang: "Shan", hide: true },
    { lang: "Shona", hide: true },
    { lang: "Sicilian", hide: true },
    { lang: "Silesian", hide: true },
    { lang: "Sindhi", hide: true },
    { lang: "Sinhala", hide: true },
    { lang: "Slovak", hide: true },
    { lang: "Slovenian", hide: true },
    { lang: "Somali", hide: true },
    { lang: "Spanish", hide: false },
    { lang: "Sundanese", hide: true },
    { lang: "Susu", hide: true },
    { lang: "Swahili", hide: true },
    { lang: "Swati", hide: true },
    { lang: "Swedish", hide: false },
    { lang: "Tahitian", hide: true },
    { lang: "Tajik", hide: true },
    { lang: "Tamazight", hide: true },
    { lang: "Tamazight (Tifinagh)", hide: true },
    { lang: "Tamil", hide: true },
    { lang: "Tatar", hide: true },
    { lang: "Telugu", hide: true },
    { lang: "Tetum", hide: true },
    { lang: "Thai", hide: false },
    { lang: "Tibetan", hide: true },
    { lang: "Tigrinya", hide: true },
    { lang: "Tiv", hide: true },
    { lang: "Tok Pisin", hide: true },
    { lang: "Tongan", hide: true },
    { lang: "Tsonga", hide: true },
    { lang: "Tswana", hide: true },
    { lang: "Tulu", hide: true },
    { lang: "Tumbuka", hide: true },
    { lang: "Turkish", hide: false },
    { lang: "Turkmen", hide: true },
    { lang: "Tuvan", hide: true },
    { lang: "Twi", hide: true },
    { lang: "Udmurt", hide: true },
    { lang: "Ukrainian", hide: true },
    { lang: "Urdu", hide: true },
    { lang: "Uyghur", hide: true },
    { lang: "Uzbek", hide: true },
    { lang: "Venda", hide: true },
    { lang: "Venetian", hide: true },
    { lang: "Vietnamese", hide: false },
    { lang: "Waray", hide: true },
    { lang: "Welsh", hide: true },
    { lang: "Wolof", hide: true },
    { lang: "Xhosa", hide: true },
    { lang: "Yakut", hide: true },
    { lang: "Yiddish", hide: true },
    { lang: "Yoruba", hide: true },
    { lang: "Yucatec Maya", hide: true },
    { lang: "Zapotec", hide: true },
    { lang: "Zulu", hide: true }
  ];

  // src/options.ts
  var SettingsManager = class {
    constructor() {
      __publicField(this, "kagiToken");
      __publicField(this, "languageFilter");
      __publicField(this, "languageGrid");
      __publicField(this, "saveButton");
      __publicField(this, "statusDiv");
      __publicField(this, "browser");
      __publicField(this, "allLanguages", ALL_LANGUAGES);
      this.browser = browser;
      this.kagiToken = document.getElementById("kagiToken");
      this.languageFilter = document.getElementById("languageFilter");
      this.languageGrid = document.getElementById("languageGrid");
      this.saveButton = document.getElementById("saveSettings");
      this.statusDiv = document.getElementById("status");
      this.showAllLangsButton = document.getElementById("showAllLangs");
      this.initialize();
    }
    initialize() {
      return __async(this, null, function* () {
        this.renderLanguagesCheckboxes(this.allLanguages);
        yield this.restoreSelectedLanguages();
        this.addEventListeners();
      });
    }
    renderLanguagesCheckboxes(languages) {
      this.languageGrid.innerHTML = "";
      languages.forEach((ob) => {
        const languageDiv = this.createLanguageCheckbox(ob.lang, ob.hide);
        this.languageGrid.appendChild(languageDiv);
      });
    }
    langToId(lang) {
      return "lang-" + lang.toLowerCase().replace(/[^a-zA-Z0-9]/g, "-");
    }
    createLanguageCheckbox(lang, isHidden) {
      const languageDiv = document.createElement("div");
      languageDiv.classList.add("language-checkbox");
      let langId = this.langToId(lang);
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.id = langId;
      checkbox.value = lang;
      const label = document.createElement("label");
      label.htmlFor = langId;
      if (isHidden) {
        languageDiv.style.display = "none";
      }
      label.textContent = lang;
      languageDiv.appendChild(checkbox);
      languageDiv.appendChild(label);
      return languageDiv;
    }
    restoreSelectedLanguages() {
      return __async(this, null, function* () {
        try {
          const result = yield this.browser.storage.sync.get(["selectedLanguages", "token"]);
          this.kagiToken.value = result.token || "";
          const selectedLanguages = result.selectedLanguages || [];
          for (let selectedLang of selectedLanguages) {
            let el = document.getElementById(this.langToId(selectedLang));
            if (el) {
              el.checked = true;
              el.parentElement.style.display = "flex";
            }
          }
        } catch (error) {
          console.error("Error restoring settings:", error);
        }
      });
    }
    addEventListeners() {
      this.saveButton.addEventListener("click", this.saveSettings.bind(this));
      this.showAllLangsButton.addEventListener("click", this.showAllLangs.bind(this));
    }
    /*
     * extracts token from url like https://kagi.com/search?token=ZZZ.YYY
     */
    getTokenOutOfURLParams() {
      this.kagiToken.value = new URLSearchParams(new URL(this.kagiToken.value).search).get("token");
    }
    saveSettings() {
      return __async(this, null, function* () {
        const selectedLanguages = this.getSelectedLanguages();
        try {
          let token = this.kagiToken.value;
          if (token.includes("kagi.com") && token.includes("token=")) {
            this.getTokenOutOfURLParams();
          }
          yield this.browser.storage.sync.set({
            token: this.kagiToken.value.trim(),
            selectedLanguages
          });
          this.showStatusMessage("Settings saved successfully!", "success");
        } catch (error) {
          this.showStatusMessage("Error saving settings", "error");
          console.error("Error saving settings:", error);
        }
      });
    }
    showAllLangs() {
      return __async(this, null, function* () {
        for (let langDiv of document.querySelectorAll(".language-checkbox")) {
          langDiv.style.display = "flex";
        }
        this.showAllLangsButton.style.display = "none";
      });
    }
    getSelectedLanguages() {
      return Array.from(document.querySelectorAll('#languageGrid input[type="checkbox"]:checked')).map((checkbox) => checkbox.value);
    }
    showStatusMessage(message, statusClass) {
      this.statusDiv.textContent = message;
      this.statusDiv.className = statusClass;
      setTimeout(() => {
        this.statusDiv.textContent = "";
        this.statusDiv.className = "";
      }, 3e3);
    }
  };
  document.addEventListener("DOMContentLoaded", () => {
    new SettingsManager();
  });
})();
