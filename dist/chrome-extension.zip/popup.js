var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
class TranslateApp {
    constructor() {
        this.translateText = document.getElementById('translateText');
        this.fromLangEl = document.getElementById('fromLang');
        this.toLangEl = document.getElementById('toLang');
        this.translateButton = document.getElementById('translateButton');
        this.reverseLangsButton = document.getElementById('reverseLangsButton');
        this.resultDiv = document.getElementById('result');
        this.settings = { token: '', fromLang: '', toLang: '', selectedLanguages: [] };
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('initialize');
            this.loadText();
            yield this.loadStoredLanguages();
            this.attachEventListeners();
        });
    }
    storeSelectedText(msg) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browser.storage.local.set({
                translatedSelectedText2: msg
            });
            console.log('storeSelectedText2');
            browser.storage.local.get('translatedSelectedText2').then((r) => { console.log(r); });
        });
    }
    /*
     * Loads either currently selected text or previously selected (if no selection)
     */
    loadText() {
        return __awaiter(this, void 0, void 0, function* () {
            const [tab] = yield browser.tabs.query({ active: true, currentWindow: true });
            let selText = yield browser.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => { return window.getSelection().toString(); }
            }).then((results) => {
                if (results && results[0]) {
                    console.log('result1: ', results);
                    let selText = results[0].result;
                    return selText;
                }
            });
            if (selText) {
                this.storeSelectedText(selText);
                this.translateText.value = selText;
                this.translateText.focus();
            }
            else {
                const storedData = yield browser.storage.local.get('translatedSelectedText2');
                if (storedData.translatedSelectedText2) {
                    this.translateText.value = storedData.translatedSelectedText2;
                    this.translateText.focus();
                }
            }
        });
    }
    loadStoredLanguages() {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield browser.storage.sync.get(['selectedLanguages', 'fromLang', 'toLang']);
            const selectedLanguages = result.selectedLanguages || [];
            this.settings.selectedLanguages = selectedLanguages;
            this.populateLanguageDropdown(this.fromLangEl, selectedLanguages);
            this.populateLanguageDropdown(this.toLangEl, selectedLanguages);
            if (result.fromLang)
                this.fromLangEl.value = result.fromLang;
            if (result.toLang)
                this.toLangEl.value = result.toLang;
        });
    }
    populateLanguageDropdown(selectElement, languages) {
        selectElement.innerHTML = '';
        languages.forEach((lang) => {
            const option = document.createElement('option');
            option.setAttribute('value', lang);
            option.textContent = lang;
            selectElement.appendChild(option);
        });
    }
    attachEventListeners() {
        this.fromLangEl.addEventListener('change', () => {
            console.log(this.fromLangEl.value);
            browser.storage.sync.set({ fromLang: this.fromLangEl.value });
        });
        this.toLangEl.addEventListener('change', () => {
            console.log(this.toLangEl.value);
            browser.storage.sync.set({ toLang: this.toLangEl.value });
        });
        this.reverseLangsButton.addEventListener('click', () => {
            this.reverseLanguages();
        });
        this.translateButton.addEventListener('click', () => __awaiter(this, void 0, void 0, function* () {
            yield this.translateTextToOtherLanguage();
        }));
    }
    reverseLanguages() {
        const tmp = this.fromLangEl.value;
        this.fromLangEl.value = this.toLangEl.value;
        this.toLangEl.value = tmp;
    }
    translateTextToOtherLanguage() {
        return __awaiter(this, void 0, void 0, function* () {
            const text = this.translateText.value.trim();
            if (!text)
                return;
            const settings = yield browser.storage.sync.get(['token']);
            const token = settings.token || '';
            console.log(token);
            console.log(settings);
            try {
                yield browser.cookies.set({
                    url: 'https://translate.kagi.com',
                    name: 'kagi_session',
                    value: token,
                    domain: '.kagi.com',
                    secure: true
                });
                const response = yield fetch('https://translate.kagi.com/?/translate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'Authorization': token,
                        'Accept': 'application/json',
                    },
                    credentials: 'include',
                    body: new URLSearchParams({
                        from: this.fromLangEl.value,
                        to: this.toLangEl.value,
                        text: text,
                    }),
                });
                if (!response.ok) {
                    throw new Error('Translation request failed');
                }
                const data = yield response.json();
                this.resultDiv.textContent = JSON.parse(data.data)[2] || 'Translation failed';
            }
            catch (error) {
                this.resultDiv.textContent = 'Error translating text';
            }
        });
    }
}
document.addEventListener('DOMContentLoaded', () => __awaiter(this, void 0, void 0, function* () {
    console.log('DOMContentLoaded');
    let xd = yield browser.storage.local.get('translatedSelectedText2');
    console.log('xd');
    console.log(xd);
    const app = new TranslateApp();
    browser.storage.local.get('translatedSelectedText2').then((s) => { console.log('STORAGE2:'); console.log(s); });
    yield app.initialize();
    browser.storage.local.get('translatedSelectedText2').then((s) => { console.log('STORAGE3:'); console.log(s); });
}));
