export function getBrowser() {
    if (typeof browser !== 'undefined') {
        // firefox
        return browser;
    }
    else if (typeof chrome !== 'undefined') {
        // chrome
        return chrome;
    }
    else {
        throw new Error('Unsupported browser environment');
    }
}
